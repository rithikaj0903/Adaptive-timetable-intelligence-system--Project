package com.project.main;

import com.project.bean.*;
import com.project.dao.*;
import com.project.dao.impl.*;

import java.util.Scanner;

public class AdaptiveTimetableApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        TeacherDAO teacherDAO = new TeacherDAOImpl();
        SubjectDAO subjectDAO = new SubjectDAOImpl();
        StudentDAO studentDAO = new StudentDAOImpl();
        TimetableDAO timetableDAO = new TimetableDAOImpl();

        int choice;

        do {
            System.out.println("\n===== Adaptive Timetable Intelligence System =====");
            System.out.println("1. Teacher Menu");
            System.out.println("2. Subject Menu");
            System.out.println("3. Student Menu");
            System.out.println("4. Timetable");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            System.out.println();

            choice = sc.nextInt();
            sc.nextLine(); // clear buffer

            switch (choice) {

                // ================= TEACHER =================
                case 1:
                    int tChoice;
                    do {
                        System.out.println("\n--- Teacher Menu ---");
                        System.out.println("1. Add Teacher");
                        System.out.println("2. View Teachers");
                        System.out.println("3. Delete Teacher");
                        System.out.println("4. Back");
                        System.out.print("Enter choice: ");
                        System.out.println();

                        tChoice = sc.nextInt();
                        sc.nextLine();

                        switch (tChoice) {
                            case 1:
                                Teacher t = new Teacher();
                                System.out.print("Teacher ID: ");
                                t.setTeacherId(sc.nextInt());
                                sc.nextLine();
                                System.out.print("Teacher Name: ");
                                t.setTeacherName(sc.nextLine());
                                System.out.print("Specialization: ");
                                t.setSpecialization(sc.nextLine());
                                teacherDAO.addTeacher(t);
                                break;

                            case 2:
                                System.out.println("\n--- Teacher List ---");
                                teacherDAO.getAllTeachers().forEach(tr ->
                                        System.out.println(
                                                tr.getTeacherId() + " | " +
                                                tr.getTeacherName() + " | " +
                                                tr.getSpecialization()
                                        )
                                );
                                break;

                            case 3:
                                System.out.print("Enter Teacher ID to delete: ");
                                teacherDAO.deleteTeacherById(sc.nextInt());
                                break;
                        }
                    } while (tChoice != 4);
                    break;

                // ================= SUBJECT =================
                case 2:
                    int sChoice;
                    do {
                        System.out.println("\n--- Subject Menu ---");
                        System.out.println("1. Add Subject");
                        System.out.println("2. View Subjects");
                        System.out.println("3. Delete Subject");
                        System.out.println("4. Back");
                        System.out.print("Enter choice: ");
                        System.out.println();

                        sChoice = sc.nextInt();
                        sc.nextLine();

                        switch (sChoice) {
                            case 1:
                                Subject s = new Subject();
                                System.out.print("Subject ID: ");
                                s.setSubjectId(sc.nextInt());
                                sc.nextLine();
                                System.out.print("Subject Name: ");
                                s.setSubjectName(sc.nextLine());
                                System.out.print("Hours per Week: ");
                                s.setHoursPerWeek(sc.nextInt());
                                subjectDAO.addSubject(s);
                                break;

                            case 2:
                                System.out.println("\n--- Subject List ---");
                                subjectDAO.getAllSubjects().forEach(sub ->
                                        System.out.println(
                                                sub.getSubjectId() + " | " +
                                                sub.getSubjectName() + " | " +
                                                sub.getHoursPerWeek()
                                        )
                                );
                                break;

                            case 3:
                                System.out.print("Enter Subject ID to delete: ");
                                subjectDAO.deleteSubjectById(sc.nextInt());
                                break;
                        }
                    } while (sChoice != 4);
                    break;

                // ================= STUDENT =================
                case 3:
                    int stChoice;
                    do {
                        System.out.println("\n--- Student Menu ---");
                        System.out.println("1. Add Student");
                        System.out.println("2. View Students");
                        System.out.println("3. Delete Student");
                        System.out.println("4. Back");
                        System.out.print("Enter choice: ");
                        System.out.println();

                        stChoice = sc.nextInt();
                        sc.nextLine();

                        switch (stChoice) {
                            case 1:
                                Student st = new Student();
                                System.out.print("Student ID: ");
                                st.setStudentId(sc.nextInt());
                                sc.nextLine();
                                System.out.print("Student Name: ");
                                st.setStudentName(sc.nextLine());
                                System.out.print("Department: ");
                                st.setDepartment(sc.nextLine());
                                System.out.print("Semester: ");
                                st.setSemester(sc.nextInt());
                                studentDAO.addStudent(st);
                                break;

                            case 2:
                                System.out.println("\n--- Student List ---");
                                studentDAO.getAllStudents().forEach(stu ->
                                        System.out.println(
                                                stu.getStudentId() + " | " +
                                                stu.getStudentName() + " | " +
                                                stu.getDepartment() + " | Sem " +
                                                stu.getSemester()
                                        )
                                );
                                break;

                            case 3:
                                System.out.print("Enter Student ID to delete: ");
                                studentDAO.deleteStudentById(sc.nextInt());
                                break;
                        }
                    } while (stChoice != 4);
                    break;

                // ================= TIMETABLE =================
                case 4:
                    int ttChoice;
                    do {
                        System.out.println("\n--- Timetable Menu ---");
                        System.out.println("1. Add Timetable");
                        System.out.println("2. View Timetable");
                        System.out.println("3. Delete Timetable by Day");
                        System.out.println("4. Back");
                        System.out.print("Enter choice: ");
                        System.out.println();

                        ttChoice = sc.nextInt();
                        sc.nextLine();

                        switch (ttChoice) {
                            case 1:
                                Timetable tt = new Timetable();
                                System.out.print("Day: ");
                                tt.setDay(sc.nextLine());
                                System.out.print("Time Slot: ");
                                tt.setTimeSlot(sc.nextLine());
                                System.out.print("Teacher ID: ");
                                tt.setTeacherId(sc.nextInt());
                                System.out.print("Subject ID: ");
                                tt.setSubjectId(sc.nextInt());
                                timetableDAO.addTimetable(tt);
                                break;

                            case 2:
                                System.out.println("\n--- Timetable ---");
                                timetableDAO.getFullTimetable().forEach(x ->
                                        System.out.println(
                                                x.getDay() + " | " +
                                                x.getTimeSlot() + " | teacher_id:" +
                                                x.getTeacherId() + " | Subject_id:" +
                                                x.getSubjectId()
                                        )
                                );
                                break;

                            case 3:
                                System.out.print("Enter Day to delete timetable : ");
                                String day = sc.nextLine();
                                timetableDAO.deleteTimetableByDay(day);
                                break;
                        }
                    } while (ttChoice != 4);
                    break;

                case 5:
                    System.out.println("Exiting... Thank you!");
                    break;

                default:
                    System.out.println("❌ Invalid choice!");
            }

        } while (choice != 5);

        sc.close();
    }
}