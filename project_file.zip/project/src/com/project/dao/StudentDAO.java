package com.project.dao;

import com.project.bean.Student;
import java.util.List;

public interface StudentDAO {

    void addStudent(Student student);
    void deleteStudentById(int id);
    List<Student> getAllStudents();
}