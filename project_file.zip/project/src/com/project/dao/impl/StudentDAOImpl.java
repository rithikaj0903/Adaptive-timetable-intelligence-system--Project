package com.project.dao.impl;

import com.project.bean.Student;
import com.project.dao.StudentDAO;
import com.project.util.ConnectionFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAOImpl implements StudentDAO {

    @Override
    public void addStudent(Student student) {
        String sql = "INSERT INTO student(name, department, semester) VALUES (?, ?, ?)";

        try (Connection con = ConnectionFactory.getConnection()) {

            if (con == null) {
                System.out.println("❌ Database connection failed");
                return;
            }

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, student.getStudentName());
            ps.setString(2, student.getDepartment());
            ps.setInt(3, student.getSemester());
            ps.executeUpdate();

            System.out.println("✅ Student added successfully");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Student> getAllStudents() {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT * FROM student";

        try (Connection con = ConnectionFactory.getConnection()) {

            if (con == null) {
                System.out.println("❌ Database connection failed");
                return list;
            }

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Student s = new Student();
                s.setStudentId(rs.getInt("id"));
                s.setStudentName(rs.getString("name"));
                s.setDepartment(rs.getString("department"));
                s.setSemester(rs.getInt("semester"));
                list.add(s);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    @Override
    public void deleteStudentById(int id) {
        String sql = "DELETE FROM student WHERE id = ?";

        try (Connection con = ConnectionFactory.getConnection()) {

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);

            int rows = ps.executeUpdate();
            System.out.println(rows > 0
                    ? "✅ Student deleted successfully"
                    : "⚠️ Student ID not found");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
