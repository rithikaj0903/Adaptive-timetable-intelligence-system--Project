package com.project.dao.impl;

import com.project.bean.Timetable;
import com.project.dao.TimetableDAO;
import com.project.util.ConnectionFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TimetableDAOImpl implements TimetableDAO {

    @Override
    public void addTimetable(Timetable timetable) {
        String sql = "INSERT INTO timetable(day, time_slot, teacher_id, subject_id) VALUES (?, ?, ?, ?)";
        try (Connection con = ConnectionFactory.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, timetable.getDay());
            ps.setString(2, timetable.getTimeSlot());
            ps.setInt(3, timetable.getTeacherId());
            ps.setInt(4, timetable.getSubjectId());
            ps.executeUpdate();

            System.out.println("Timetable entry added.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Timetable> getFullTimetable() {
        List<Timetable> list = new ArrayList<>();
        String sql = "SELECT * FROM timetable";

        try (Connection con = ConnectionFactory.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Timetable t = new Timetable();
                t.setTimetableId(rs.getInt("id"));
                t.setDay(rs.getString("day"));
                t.setTimeSlot(rs.getString("time_slot"));
                t.setTeacherId(rs.getInt("teacher_id"));
                t.setSubjectId(rs.getInt("subject_id"));
                list.add(t);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    @Override
    public void deleteTimetableByDay(String day) {

        String sql = "DELETE FROM timetable WHERE day = ?";

        try (Connection con = ConnectionFactory.getConnection()) {

            if (con == null) {
                System.out.println("❌ Database connection failed");
                return;
            }

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, day);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("✅ Timetable deleted for day: " + day);
            } else {
                System.out.println("⚠️ No timetable found for day: " + day);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}