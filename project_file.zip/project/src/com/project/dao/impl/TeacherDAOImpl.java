package com.project.dao.impl;

import com.project.bean.Teacher;
import com.project.dao.TeacherDAO;
import com.project.util.ConnectionFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TeacherDAOImpl implements TeacherDAO {

    @Override
    public void addTeacher(Teacher teacher) {
        String sql = "INSERT INTO teacher(name, specialization) VALUES (?, ?)";
        try (Connection con = ConnectionFactory.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, teacher.getTeacherName());
            ps.setString(2, teacher.getSpecialization());
            ps.executeUpdate();

            System.out.println("Teacher added successfully.");

        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Teacher> getAllTeachers() {
        List<Teacher> list = new ArrayList<>();
        String sql = "SELECT * FROM teacher";

        try (Connection con = ConnectionFactory.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Teacher t = new Teacher();
                t.setTeacherId(rs.getInt("id"));
                t.setTeacherName(rs.getString("name"));
                t.setSpecialization(rs.getString("specialization"));
                list.add(t);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    @Override
    public void deleteTeacherById(int id) {
        String sql = "DELETE FROM teacher WHERE id = ?";

        try (Connection con = ConnectionFactory.getConnection()) {

            if (con == null) {
                System.out.println("❌ DB connection failed");
                return;
            }

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);

            int rows = ps.executeUpdate();
            System.out.println(rows > 0
                    ? "✅ Teacher deleted successfully"
                    : "⚠️ Teacher ID not found");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
