package com.project.dao.impl;

import com.project.bean.Subject;
import com.project.dao.SubjectDAO;
import com.project.util.ConnectionFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SubjectDAOImpl implements SubjectDAO {

    @Override
    public void addSubject(Subject subject) {
        String sql = "INSERT INTO subject(name, hours_per_week) VALUES (?, ?)";
        try (Connection con = ConnectionFactory.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, subject.getSubjectName());
            ps.setInt(2, subject.getHoursPerWeek());
            ps.executeUpdate();

            System.out.println("Subject added successfully.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Subject> getAllSubjects() {
        List<Subject> list = new ArrayList<>();
        String sql = "SELECT * FROM subject";

        try (Connection con = ConnectionFactory.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Subject s = new Subject();
                s.setSubjectId(rs.getInt("id"));
                s.setSubjectName(rs.getString("name"));
                s.setHoursPerWeek(rs.getInt("hours_per_week"));
                list.add(s);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    @Override
    public void deleteSubjectById(int id) {
        String sql = "DELETE FROM subject WHERE id = ?";

        try (Connection con = ConnectionFactory.getConnection()) {

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);

            int rows = ps.executeUpdate();
            System.out.println(rows > 0
                    ? "✅ Subject deleted successfully"
                    : "⚠️ Subject ID not found");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}