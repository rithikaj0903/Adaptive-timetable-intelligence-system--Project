package com.project.dao;

import com.project.bean.Subject;
import java.util.List;

public interface SubjectDAO {

    void addSubject(Subject subject);
    void deleteSubjectById(int id);
    List<Subject> getAllSubjects();
}