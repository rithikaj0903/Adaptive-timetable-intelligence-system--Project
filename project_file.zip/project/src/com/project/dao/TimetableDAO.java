package com.project.dao;

import com.project.bean.Timetable;
import java.util.List;

public interface TimetableDAO {

    void addTimetable(Timetable timetable);
    void deleteTimetableByDay(String day);
    List<Timetable> getFullTimetable();
}