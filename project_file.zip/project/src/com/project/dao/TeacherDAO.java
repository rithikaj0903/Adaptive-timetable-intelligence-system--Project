package com.project.dao;

import com.project.bean.Teacher;
import java.util.List;

public interface TeacherDAO {

    void addTeacher(Teacher teacher);
    void deleteTeacherById(int id);
    List<Teacher> getAllTeachers();
}
